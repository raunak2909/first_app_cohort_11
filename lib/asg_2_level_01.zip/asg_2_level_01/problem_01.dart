/// Question here
void main(){



}